CREATE TABLE sales (
id INT PRIMARY KEY,
region VARCHAR(50),
category VARCHAR(50),
sales INT,
profit INT
);